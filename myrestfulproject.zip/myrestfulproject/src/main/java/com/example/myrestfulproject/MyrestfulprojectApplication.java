package com.example.myrestfulproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyrestfulprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyrestfulprojectApplication.class, args);
    }

}
