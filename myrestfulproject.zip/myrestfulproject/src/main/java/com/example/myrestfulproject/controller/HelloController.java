package com.example.myrestfulproject.controller;

import com.example.myrestfulproject.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
public class HelloController {

    @RequestMapping("/hello")
    public String hello(Model model){
        model.addAttribute("new", DateFormat.getDateTimeInstance().format(new Date()));

        return "hello1";
    }
    @RequestMapping("/hello/{id}")
    public String requestHello(@PathVariable(name = "id") String id, @RequestParam(name = "name") String name) throws Exception {
        System.out.println("id:"+id);
        System.out.println("name:"+name);
        return name;
    }
//    @RequestMapping("")
//    public List<String> getList(){
////        model.addAttribute("new", DateFormat.getDateTimeInstance().format(new Date()));
//        List<Student> list = new ArrayList<>();
//        Student student = new Student("xiaoming",1,"nan");
//        Student student2 = new Student("zhangsan",2,"nan");
//        Student student3 = new Student("lisi",3,"nan");
//
//
//        return list;
//    }

}
